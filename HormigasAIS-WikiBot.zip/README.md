# HormigasAIS-WikiBot

**HormigasAIS-WikiBot** es un bot experimental vinculado a la comunidad de HormigasAIS en Discord. Su propósito es proporcionar enlaces útiles, fomentar la exploración en Wikipedia, y promover el uso ético de la inteligencia artificial.

## Funcionalidades
- Compartir enlaces directos a páginas clave de Wikipedia relacionadas con HormigasAIS.
- Fomentar la participación en retos y dinámicas semanales.
- Integración futura con eventos de Dyno, GitHub y otras herramientas del enjambre.

## Requisitos
- Python 3.8+
- `discord.py`
- `requests`

## Instalación
```bash
git clone https://github.com/HormigasAIS/HormigasAIS-WikiBot.git
cd HormigasAIS-WikiBot
pip install -r requirements.txt
```

## Ejecutar el bot
```bash
python bot.py
```

## Licencia
[MIT](LICENSE)
