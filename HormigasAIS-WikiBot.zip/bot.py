import discord
from discord.ext import commands

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"Conectado como {bot.user}")

@bot.command()
async def wiki(ctx):
    await ctx.send("Consulta el perfil de HormigasAIS en Wikipedia: https://en.wikipedia.org/wiki/User:HormigasaiS.A")

bot.run("YOUR_DISCORD_BOT_TOKEN")
